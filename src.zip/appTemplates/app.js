require('passkee').init(__dirname+'/config/config.js');
//require('passkee').make();