module.exports = {
	add:function(sio){
		sio.emit('news','book added');
	},
};




