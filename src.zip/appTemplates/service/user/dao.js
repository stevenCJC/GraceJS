var app=global.app;


module.exports = {
	
	get:function(handle){
		
	},
	del:function(handle){
		
	},
	add:function(handle){
		
	},
	
	
	
};




