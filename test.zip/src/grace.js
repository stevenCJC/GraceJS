define([
	"./event",
], function( jQuery ) {
var document = window.document;
return document;

});
